# horse_detection > horse_detection_2
https://universe.roboflow.com/nilayroboflow/horse_detection-zps6g

Provided by a Roboflow user
License: CC BY 4.0

